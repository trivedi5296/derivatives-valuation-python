"""Single-curve valuation on annual, synthetic SOFR OIS quotes."""
import csv
from math import isclose, isfinite
from pathlib import Path

QUOTE_FILE = Path(__file__).with_name("synthetic_sofr_ois.csv")
BASIS_POINT = 0.0001
NOTIONAL = 10_000_000


def load_quotes(path=QUOTE_FILE):
    with open(path, newline="") as handle:
        return [(int(row["tenor_years"]), float(row["par_rate_pct"]) / 100)
                for row in csv.DictReader(handle)]


def bootstrap(quotes):
    """Return annual discount factors, including D(0) = 1."""
    discounts = [1.0]
    prior_annuity = 0.0
    for expected_year, (year, par_rate) in enumerate(quotes, start=1):
        if year != expected_year:
            raise ValueError("Quotes must cover consecutive annual maturities from year 1.")
        if not isfinite(par_rate) or par_rate <= -1.0:
            raise ValueError(f"Invalid par rate at year {year}.")
        discount = (1.0 - par_rate * prior_annuity) / (1.0 + par_rate)
        if discount <= 0 or not isfinite(discount):
            raise ValueError(f"Invalid discount factor at year {year}.")
        discounts.append(discount)
        prior_annuity += discount
    return discounts


def swap_terms(discounts, start, end):
    if not 0 <= start < end < len(discounts):
        raise ValueError("Swap dates must lie on annual curve nodes.")
    annuity = sum(discounts[start + 1:end + 1])
    floating_pv_per_dollar = discounts[start] - discounts[end]
    return annuity, floating_pv_per_dollar / annuity


def payer_pv(discounts, start, end, fixed_rate, notional):
    annuity, par_rate = swap_terms(discounts, start, end)
    return notional * annuity * (par_rate - fixed_rate)


def main():
    quotes = load_quotes()
    curve = bootstrap(quotes)
    for year, quoted_rate in quotes:
        _, fitted_rate = swap_terms(curve, 0, year)
        assert isclose(fitted_rate, quoted_rate, rel_tol=0, abs_tol=1e-12)
        assert abs(payer_pv(curve, 0, year, quoted_rate, NOTIONAL)) < 1e-6
    _, coupon = swap_terms(curve, 0, 5)
    bumped_up = bootstrap([(year, rate + BASIS_POINT) for year, rate in quotes])
    bumped_down = bootstrap([(year, rate - BASIS_POINT) for year, rate in quotes])
    base_pv = payer_pv(curve, 0, 5, coupon, NOTIONAL)
    up_pv = payer_pv(bumped_up, 0, 5, coupon, NOTIONAL)
    down_pv = payer_pv(bumped_down, 0, 5, coupon, NOTIONAL)
    assert down_pv < base_pv < up_pv
    print(f"Calibration: {len(quotes)} quotes repriced within 1e-8 bp")
    print(f"5Y par coupon: {coupon:.3%} | PV at par: ${base_pv:,.2f}")
    print(f"PV change for +1 bp quote bump: ${up_pv - base_pv:,.2f}")
    print(f"PV change for -1 bp quote bump: ${down_pv - base_pv:,.2f}")
    print(f"Central-difference PV sensitivity per +1 bp: ${(up_pv - down_pv) / 2:,.2f}")


if __name__ == "__main__":
    main()
