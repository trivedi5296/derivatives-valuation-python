# PricingDirect portfolio exercises

Three scripts use sample inputs so you can reproduce the results and explain the assumptions. The curve quotes and option inputs are synthetic. The rates models use a single curve, annual accruals of exactly one year, and integer-year maturities. They omit production date conventions, payment lags, collateral adjustments, and volatility-surface calibration.

## Run on your Mac

Open Terminal, change into the extracted folder, then run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install numpy
python sofr_swap.py
python swaption.py
python equity_monte_carlo.py
```

The rates scripts use the Python standard library. NumPy is required for the Monte Carlo script.

| Script | What it calculates | Expected check |
| --- | --- | --- |
| `sofr_swap.py` | Discount factors from 1Y–10Y par OIS quotes, 5Y pay-fixed swap PV, and parallel quote risk | The 5Y par coupon is 3.740% and the PV is $0.00. Rebootstrapping after a +1 bp move increases PV by about $4,485 on $10 million notional. |
| `swaption.py` | A 1Y × 5Y physical European payer and receiver swaption using Bachelier, with strike scenarios and vega | At the money both sides are worth about $129,351 at 75 bp normal vol. At all strikes, payer PV minus receiver PV equals the underlying forward payer swap PV. |
| `equity_monte_carlo.py` | European call and put prices using antithetic terminal draws, with standard errors and 95% intervals | At 200,000 pairs, seeded MC prices are about $9.5854 and $10.4507. The Black–Scholes values are $9.5563 and $10.4391. |

## Explain the calculations

- **Swap.** The floating leg of this simplified single-curve swap is worth `N × (D(start) − D(end))`. The fixed leg is worth `N × K × A`, where `A` sums the discounted accrual factors. At par those legs have equal PV. The risk check shifts the input quotes and rebuilds the curve while holding the trade coupon fixed.
- **Swaption.** A payer swaption gives the right to pay fixed. In Bachelier, the forward swap rate has a normal distribution with terminal standard deviation `normal_vol × sqrt(expiry)`. Multiply the expected rate payoff by the discounted fixed-leg annuity and the notional. A volatility of 75 bp means 0.0075 in decimal rate units.
- **Monte Carlo.** Draw a standard normal shock and its negative, generate terminal prices under risk-neutral geometric Brownian motion, and average the discounted payoffs within each pair. Compute the standard error across pair averages because the two payoffs within each pair are dependent. The benchmark is the closed-form Black–Scholes price under the same inputs.

## Make the projects your own before interviewing

Change the 5Y quote in the CSV and explain why the coupon of an existing trade must stay fixed when you recalculate its risk. Change the swaption strike and explain which side gets more expensive. Re-run Monte Carlo with a different seed and explain why sampling error changes. Be ready to explain which simplifications you would revisit for a real market close.

## References

- [OpenGamma Strata swap pricing and par rate](https://strata.opengamma.io/apidocs/com/opengamma/strata/pricer/swap/DiscountingSwapProductPricer.html)
- [OpenGamma Strata swaption pricers](https://strata.opengamma.io/apidocs/com/opengamma/strata/pricer/swaption/package-summary.html)
