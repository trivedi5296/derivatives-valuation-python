"""Benchmark Monte Carlo European equity options against Black-Scholes."""
from math import exp, log, sqrt
from statistics import NormalDist

import numpy as np

NORMAL = NormalDist()


def black_scholes(spot, strike, rate, volatility, expiry, direction):
    sigma_root_t = volatility * sqrt(expiry)
    d1 = (log(spot / strike) + (rate + 0.5 * volatility**2) * expiry) / sigma_root_t
    d2 = d1 - sigma_root_t
    return direction * (spot * NORMAL.cdf(direction * d1)
                        - strike * exp(-rate * expiry) * NORMAL.cdf(direction * d2))


def terminal_prices(spot, rate, volatility, expiry, draws):
    drift = (rate - 0.5 * volatility**2) * expiry
    return spot * np.exp(drift + volatility * sqrt(expiry) * draws)


def main():
    spot, strike, rate, volatility, expiry = 100.0, 105.0, 0.04, 0.25, 1.0
    draws = np.random.default_rng(42).standard_normal(200_000)
    terminal = terminal_prices(spot, rate, volatility, expiry, draws)
    antithetic = terminal_prices(spot, rate, volatility, expiry, -draws)
    discount = exp(-rate * expiry)
    print("Option   Pairs     MC price   Std. error       95% CI       Black-Scholes")
    for option, direction in (("Call", 1), ("Put", -1)):
        benchmark = black_scholes(spot, strike, rate, volatility, expiry, direction)
        assert benchmark > 0
        discounted_payoffs = discount * np.maximum(direction * (terminal - strike), 0)
        antithetic_payoffs = discount * np.maximum(direction * (antithetic - strike), 0)
        pair_averages = 0.5 * (discounted_payoffs + antithetic_payoffs)
        for pair_count in (1_000, 10_000, 200_000):
            used_pairs = pair_averages[:pair_count]
            estimate = float(used_pairs.mean())
            error = float(used_pairs.std(ddof=1) / sqrt(pair_count))
            low, high = estimate - 1.96 * error, estimate + 1.96 * error
            print(f"{option:5} {pair_count:7,d} {estimate:11.4f} {error:11.4f}"
                  f"    [{low:.4f}, {high:.4f}]     {benchmark:.4f}")
        assert abs(estimate - benchmark) < 4 * error, "Seeded benchmark outside 4 SE."
    call = black_scholes(spot, strike, rate, volatility, expiry, 1)
    put = black_scholes(spot, strike, rate, volatility, expiry, -1)
    assert abs(call - put - (spot - discount * strike)) < 1e-12
    print("Black-Scholes put-call parity and seeded Monte Carlo benchmark checks passed.")


if __name__ == "__main__":
    main()
