"""Bachelier valuation for an illustrative physical European SOFR swaption."""
from math import isclose, sqrt
from statistics import NormalDist

from sofr_swap import BASIS_POINT, NOTIONAL, bootstrap, load_quotes, swap_terms

NORMAL = NormalDist()


def swaption_pv(forward, strike, normal_vol, expiry, annuity, notional, payer=True):
    if normal_vol < 0 or expiry < 0:
        raise ValueError("Normal volatility and expiry must be nonnegative.")
    direction = 1 if payer else -1
    moneyness = direction * (forward - strike)
    standard_deviation = normal_vol * sqrt(expiry)
    if standard_deviation == 0:
        return notional * annuity * max(moneyness, 0)
    standardized = moneyness / standard_deviation
    expected_payoff = (moneyness * NORMAL.cdf(standardized)
                       + standard_deviation * NORMAL.pdf(standardized))
    return notional * annuity * expected_payoff


def main():
    expiry, end = 1, 6
    curve = bootstrap(load_quotes())
    annuity, forward = swap_terms(curve, expiry, end)
    normal_vol = 75 * BASIS_POINT
    print(f"1Y x 5Y swaption | Forward swap rate: {forward:.4%} | Normal vol: 75 bp")
    print("Strike offset     Payer PV     Receiver PV    Payer vega (+1 normal-vol bp)")
    for offset in (-50, 0, 50):
        strike = forward + offset * BASIS_POINT
        payer = swaption_pv(forward, strike, normal_vol, expiry, annuity, NOTIONAL)
        receiver = swaption_pv(forward, strike, normal_vol, expiry, annuity, NOTIONAL, payer=False)
        forward_swap_pv = NOTIONAL * annuity * (forward - strike)
        assert isclose(payer - receiver, forward_swap_pv, abs_tol=1e-7)
        bumped = swaption_pv(forward, strike, normal_vol + BASIS_POINT, expiry, annuity, NOTIONAL)
        assert bumped > payer >= 0
        print(f"{offset:+4d} bp      ${payer:>11,.2f}   ${receiver:>11,.2f}   ${bumped - payer:>11,.2f}")
    print("Payer-receiver parity passed at all three strikes.")


if __name__ == "__main__":
    main()
